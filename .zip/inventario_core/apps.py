from django.apps import AppConfig


class InventarioCoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'inventario_core'
