from rest_framework.permissions import BasePermission, SAFE_METHODS

def _is_in_group(user, group_name: str) -> bool:
    return user.is_authenticated and user.groups.filter(name=group_name).exists()

class RoleByResourcePermission(BasePermission):
    """
    Reglas:
    - Admin/superuser: todo.
    - Consultor: solo lectura (GET/HEAD/OPTIONS).
    - Vendedor: lectura en todo + puede POST en Movimiento.
    - Otros: sin acceso.
    """
    def has_permission(self, request, view):
        user = request.user
        if not user.is_authenticated:
            return False

        if user.is_superuser or _is_in_group(user, "Administrador"):
            return True

        is_consultor = _is_in_group(user, "Consultor")
        is_vendedor = _is_in_group(user, "Vendedor")

        if is_consultor:
            return request.method in SAFE_METHODS

        if is_vendedor:
            if request.method in SAFE_METHODS:
                return True
            # Permitir crear Movimientos (POST)
            view_name = view.__class__.__name__.lower()
            if request.method == "POST" and "movimiento" in view_name:
                return True
            return False

        return False
